/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.terceiroo;

/**
 *
 * @author GeoDantas
 */
import java.util.*;

class Aviao {
    String nome;
    int id;
    Aviao(String nome, int id) {
        this.nome = nome;
        this.id = id;
    }
    public String toString() {
        return nome + " (ID: " + id + ")";
    }
}

public class Terceiroo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Queue<Aviao> fila = new LinkedList<>();
        int opcao;

        do {
            System.out.println("\n1- Listar aviões na fila");
            System.out.println("2- Autorizar decolagem");
            System.out.println("3- Adicionar avião");
            System.out.println("4- Listar todos os aviões");
            System.out.println("5- Mostrar o primeiro da fila");
            System.out.println("0- Sair");
            System.out.print("Escolha: ");
            opcao = sc.nextInt(); sc.nextLine();

            switch (opcao) {
                case 1 -> System.out.println("Aviões aguardando: " + fila.size());
                case 2 -> {
                    if (fila.isEmpty()) System.out.println("Fila vazia!");
                    else System.out.println("Decolou: " + fila.poll());
                }
                case 3 -> {
                    System.out.print("Nome: ");
                    String nome = sc.nextLine();
                    System.out.print("ID: ");
                    int id = sc.nextInt();
                    fila.add(new Aviao(nome, id));
                }
                case 4 -> System.out.println("Fila: " + fila);
                case 5 -> System.out.println("Primeiro da fila: " + (fila.peek() != null ? fila.peek() : "Nenhum"));
            }
        } while (opcao != 0);
    }
}

