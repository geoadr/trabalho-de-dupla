/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quintoo;

/**
 *
 * @author GeoDantas
 */
import java.util.*;

public class Quintoo {
    public static void main(String[] args) {
        Queue<Integer> F = new LinkedList<>();
        Stack<Integer> P = new Stack<>();
        Random r = new Random();

        for (int i = 0; i < 1000; i++) {
            int num = r.nextInt(2000);
            if (F.contains(num)) P.push(num);
            else F.add(num);
        }

        System.out.println("fila f: " + F);
        System.out.println("pilha p: " + P);
    }
}
