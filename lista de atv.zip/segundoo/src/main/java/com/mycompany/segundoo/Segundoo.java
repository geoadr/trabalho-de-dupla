/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.segundoo;

/**
 *
 * @author GeoDantas
 */
import java.util.*;

public class Segundoo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Stack<Integer> pilha = new Stack<>();
        Stack<Integer> aux = new Stack<>();

        
        for (int i = 1; i <= 5; i++) pilha.push(i);
        System.out.println("pilha original: " + pilha);

        System.out.print("digite o valor a remover bem aqui pfvr: ");
        int c = sc.nextInt();

        while (!pilha.isEmpty()) {
            int topo = pilha.pop();
            if (topo != c)
                aux.push(topo);
        }

        while (!aux.isEmpty()) pilha.push(aux.pop());

        System.out.println("pilha após remoção: " + pilha);
    }
}

