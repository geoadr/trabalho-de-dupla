/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.oitavoo;

/**
 *
 * @author GeoDantas
 */
import java.util.*;

class TestaPilha {
    Stack<Integer> P = new Stack<>();
    Stack<Integer> N = new Stack<>();

    void executar() {
        Random r = new Random();
        for (int i = 0; i < 1000; i++) {
            int num = r.nextInt(201) - 100; // -100 a 100
            if (num > 0) P.push(num);
            else if (num < 0) N.push(num);
            else if (!P.isEmpty() && !N.isEmpty())
                System.out.println("zeroo! retirados: " + P.pop() + " e " + N.pop());
        }
    }
}

public class Oitavoo {
    public static void main(String[] args) {
        TestaPilha t = new TestaPilha();
        t.executar();
    }
}

