/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sextoo;

/**
 *
 * @author GeoDantas
 */
import java.util.*;

public class Sextoo {
    public static void main(String[] args) {
        Queue<Integer> fila = new LinkedList<>();
        Stack<Integer> pilha = new Stack<>();
        Random r = new Random();

        for (int i = 0; i < 1000; i++) fila.add(r.nextInt(100) + 1);
        for (int i = 0; i < 1000; i++) fila.add(-r.nextInt(100) - 1);

        while (!fila.isEmpty()) {
            int num = fila.peek();
            if (num > 0) pilha.push(fila.poll());
            else {
                fila.poll();
                if (!pilha.isEmpty())
                    System.out.println("desempilhado: " + pilha.pop());
            }
        }
    }
}

