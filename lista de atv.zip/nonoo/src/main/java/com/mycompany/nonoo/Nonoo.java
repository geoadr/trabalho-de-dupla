/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.nonoo;

/**
 *
 * @author GeoDantas
 */
import java.util.*;

public class Nonoo {
    public static int somaRecursiva(List<Integer> lista, int i) {
        if (i == lista.size()) return 0;
        return lista.get(i) + somaRecursiva(lista, i + 1);
    }

    public static void main(String[] args) {
        List<Integer> numeros = Arrays.asList(1, 2, 3, 4);
        System.out.println("soma é = " + somaRecursiva(numeros, 0));
    }
}

