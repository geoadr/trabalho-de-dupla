/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quartoo;

/**
 *
 * @author GeoDantas
 */
import java.util.*;

public class Quartoo {
    public static void main(String[] args) {
        Queue<Integer> F1 = new LinkedList<>();
        Random r = new Random();

        for (int i = 0; i < 10; i++) F1.add(r.nextInt(100));

        System.out.println("fila original aqui: " + F1);
        Queue<Integer> F2 = inverterFila(F1);
        System.out.println("fila invertida bem aqui: " + F2);
    }

    public static Queue<Integer> inverterFila(Queue<Integer> F1) {
        Stack<Integer> pilha = new Stack<>();
        for (int num : F1) pilha.push(num);

        Queue<Integer> F2 = new LinkedList<>();
        while (!pilha.isEmpty()) F2.add(pilha.pop());
        return F2;
    }
}
