/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ultimoo;

/**
 *
 * @author GeoDantas
 */
import java.util.*;

public class Ultimoo {
    public static int potencia(int a, int b) {
        if (b == 0) return 1;
        return a * potencia(a, b - 1);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("digite a base bem aq: ");
        int a = sc.nextInt();
        System.out.print("digite o expoente tambem: ");
        int b = sc.nextInt();
        System.out.println(a + "^" + b + " = " + potencia(a, b));
    }
}

