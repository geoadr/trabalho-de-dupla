/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.setimoo;

/**
 *
 * @author GeoDantas
 */
import java.util.*;

public class Setimoo {
    public static void main(String[] args) {
        Queue<Integer> fila = new LinkedList<>();
        Stack<Integer> pilha = new Stack<>();
        Random r = new Random();

        for (int i = 0; i < 20; i++) fila.add(r.nextInt(100));

        System.out.println("fila original aqui: " + fila);

        while (!fila.isEmpty()) pilha.push(fila.poll());
        while (!pilha.isEmpty()) fila.add(pilha.pop());

        System.out.println("fila invertida aq: " + fila);
    }
}

