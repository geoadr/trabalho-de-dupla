/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.primeiroo;

/**
 *
 * @author GeoDantas
 */
import java.util.*;

public class Primeiroo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Stack<Character> pilha = new Stack<>();

        System.out.print("Digite um texto bem aqui: ");
        String texto = sc.nextLine();

        
        for (char c : texto.toCharArray()) {
            pilha.push(c);
        }

        System.out.print("Texto invertido: ");
        while (!pilha.isEmpty()) {
            System.out.print(pilha.pop());
        }
        System.out.println();

        
        String textoLimpo = texto.replaceAll("[ .]", "").toLowerCase();
        String reverso = new StringBuilder(textoLimpo).reverse().toString();

        if (textoLimpo.equals(reverso))
            System.out.println("UHUUL, é um palíndromoo!");
        else
            System.out.println("Não é um palíndromo!");
    }
}

